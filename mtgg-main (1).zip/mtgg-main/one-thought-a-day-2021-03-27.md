---
title: one-thought-a-day-2021-03-27
author: lingzi
tags:
  - 唐总
categories:
  - 金句
date: 2021-03-27
---

今天收集了唐总的一句话：

> 软件不是一个行业，它是服务于各行各业。对于各行各业来说，我们都是外行。
