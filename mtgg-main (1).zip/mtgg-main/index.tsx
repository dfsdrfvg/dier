import React from 'react';
import ReactDOM from 'react-dom';
import IndexPage from './src/page/index';

ReactDOM.render( <IndexPage />, document.getElementById('app') );